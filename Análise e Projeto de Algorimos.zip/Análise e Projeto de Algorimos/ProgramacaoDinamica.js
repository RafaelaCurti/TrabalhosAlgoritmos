// Programação Dinãmica

function copo(capacidade, arrayPesos, arrayValores, a) {
    const matriz = [];
  
    for (let indice= 0; indice<= a; indice++) {
      matriz[indice] = [];
      for (let j = 0; j <= capacidade; j++) {
        matriz[i][j] = 0;
      }
    }
  
    for (let indice= 1; indice<= a; indice++) {
      for (let j = 1; j <= capacidade; j++) {
        if (arrayPesos[indice- 1] > j) {
          matriz[indice][j] = matriz[indice- 1][j];
        } else {
          matriz[indice][j] = Math.max(matriz[indice- 1][j], arrayValores[indice- 1] + matriz[indice- 1][j - arrayPesos[indice- 1]]);
        }
      }
    }
  
    return matriz[a][capacidade];
  }
  
  const capacidade = 50;
  const arrayPesos = [10, 20, 30];
  const arrayValores = [60, 100, 120];
  const a = arrayPesos.length;
  
  const maximo = copo(capacidade, arrayPesos, arrayValores, a);
  console.log(maximo);